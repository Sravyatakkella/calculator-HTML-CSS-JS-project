# Calculator App

A sleek, production-ready calculator built with React + Vite.

## Features
- Basic arithmetic: +, −, ×, ÷
- Percentage and sign toggle
- Keyboard support
- Expression history display
- Error handling (division by zero)
- Responsive design

## Deploy to Vercel

### Option 1: Vercel CLI
```bash
npm i -g vercel
npm install
vercel
```

### Option 2: GitHub + Vercel Dashboard
1. Push this folder to a GitHub repo
2. Go to https://vercel.com/new
3. Import your repo → Vercel auto-detects Vite
4. Click **Deploy**

## Local Development
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```
