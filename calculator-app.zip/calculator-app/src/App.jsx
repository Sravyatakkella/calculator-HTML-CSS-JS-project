import { useState, useEffect, useCallback } from 'react'
import './App.css'

const BUTTONS = [
  [
    { label: 'AC', type: 'clear', wide: false },
    { label: '+/-', type: 'sign', wide: false },
    { label: '%', type: 'percent', wide: false },
    { label: '÷', type: 'operator', value: '/' },
  ],
  [
    { label: '7', type: 'number' },
    { label: '8', type: 'number' },
    { label: '9', type: 'number' },
    { label: '×', type: 'operator', value: '*' },
  ],
  [
    { label: '4', type: 'number' },
    { label: '5', type: 'number' },
    { label: '6', type: 'number' },
    { label: '−', type: 'operator', value: '-' },
  ],
  [
    { label: '1', type: 'number' },
    { label: '2', type: 'number' },
    { label: '3', type: 'number' },
    { label: '+', type: 'operator', value: '+' },
  ],
  [
    { label: '0', type: 'number', wide: true },
    { label: '.', type: 'decimal' },
    { label: '=', type: 'equals' },
  ],
]

function formatDisplay(value) {
  if (value === 'Error') return 'Error'
  const num = parseFloat(value)
  if (isNaN(num)) return value
  if (Math.abs(num) >= 1e13 || (Math.abs(num) < 1e-6 && num !== 0)) {
    return num.toExponential(4)
  }
  const str = value.toString()
  if (str.includes('.')) {
    const parts = str.split('.')
    const formatted = parseFloat(parts[0]).toLocaleString('en-US') + '.' + parts[1]
    return formatted.length > 12 ? parseFloat(value).toPrecision(9) : formatted
  }
  const formatted = num.toLocaleString('en-US')
  return formatted
}

export default function App() {
  const [display, setDisplay] = useState('0')
  const [prevValue, setPrevValue] = useState(null)
  const [operator, setOperator] = useState(null)
  const [waitingForNext, setWaitingForNext] = useState(false)
  const [expression, setExpression] = useState('')
  const [justCalculated, setJustCalculated] = useState(false)
  const [activeBtn, setActiveBtn] = useState(null)

  const calculate = useCallback((a, b, op) => {
    const numA = parseFloat(a)
    const numB = parseFloat(b)
    switch (op) {
      case '+': return (numA + numB).toString()
      case '-': return (numA - numB).toString()
      case '*': return (numA * numB).toString()
      case '/':
        if (numB === 0) return 'Error'
        return (numA / numB).toString()
      default: return b
    }
  }, [])

  const handleNumber = useCallback((num) => {
    if (justCalculated) {
      setDisplay(num)
      setJustCalculated(false)
      setExpression('')
      return
    }
    if (waitingForNext) {
      setDisplay(num)
      setWaitingForNext(false)
      return
    }
    if (display === '0') {
      setDisplay(num)
    } else {
      if (display.replace('-', '').replace('.', '').length >= 12) return
      setDisplay(display + num)
    }
  }, [display, waitingForNext, justCalculated])

  const handleDecimal = useCallback(() => {
    if (justCalculated) {
      setDisplay('0.')
      setJustCalculated(false)
      setExpression('')
      return
    }
    if (waitingForNext) {
      setDisplay('0.')
      setWaitingForNext(false)
      return
    }
    if (!display.includes('.')) {
      setDisplay(display + '.')
    }
  }, [display, waitingForNext, justCalculated])

  const handleOperator = useCallback((op) => {
    setJustCalculated(false)
    if (prevValue !== null && !waitingForNext) {
      const result = calculate(prevValue, display, operator)
      if (result === 'Error') {
        setDisplay('Error')
        setPrevValue(null)
        setOperator(null)
        setExpression('')
        setWaitingForNext(false)
        return
      }
      setPrevValue(result)
      setDisplay(result)
      const opSymbol = { '/': '÷', '*': '×', '-': '−', '+': '+' }[op] || op
      setExpression(result + ' ' + opSymbol)
    } else {
      const opSymbol = { '/': '÷', '*': '×', '-': '−', '+': '+' }[op] || op
      setExpression(display + ' ' + opSymbol)
      setPrevValue(display)
    }
    setOperator(op)
    setWaitingForNext(true)
  }, [prevValue, display, operator, waitingForNext, calculate])

  const handleEquals = useCallback(() => {
    if (prevValue === null || operator === null) return
    const opSymbol = { '/': '÷', '*': '×', '-': '−', '+': '+' }[operator] || operator
    const expr = prevValue + ' ' + opSymbol + ' ' + display
    const result = calculate(prevValue, display, operator)
    setExpression(expr + ' =')
    setDisplay(result === 'Error' ? 'Error' : result)
    setPrevValue(null)
    setOperator(null)
    setWaitingForNext(false)
    setJustCalculated(true)
  }, [prevValue, display, operator, calculate])

  const handleClear = useCallback(() => {
    setDisplay('0')
    setPrevValue(null)
    setOperator(null)
    setWaitingForNext(false)
    setExpression('')
    setJustCalculated(false)
  }, [])

  const handleSign = useCallback(() => {
    if (display === '0' || display === 'Error') return
    setDisplay(display.startsWith('-') ? display.slice(1) : '-' + display)
    setJustCalculated(false)
  }, [display])

  const handlePercent = useCallback(() => {
    if (display === 'Error') return
    const val = parseFloat(display) / 100
    setDisplay(val.toString())
    setJustCalculated(false)
  }, [display])

  const handleClick = useCallback((btn) => {
    setActiveBtn(btn.label)
    setTimeout(() => setActiveBtn(null), 150)
    switch (btn.type) {
      case 'number': handleNumber(btn.label); break
      case 'decimal': handleDecimal(); break
      case 'operator': handleOperator(btn.value || btn.label); break
      case 'equals': handleEquals(); break
      case 'clear': handleClear(); break
      case 'sign': handleSign(); break
      case 'percent': handlePercent(); break
    }
  }, [handleNumber, handleDecimal, handleOperator, handleEquals, handleClear, handleSign, handlePercent])

  // Keyboard support
  useEffect(() => {
    const keyMap = {
      '0': () => handleNumber('0'),
      '1': () => handleNumber('1'),
      '2': () => handleNumber('2'),
      '3': () => handleNumber('3'),
      '4': () => handleNumber('4'),
      '5': () => handleNumber('5'),
      '6': () => handleNumber('6'),
      '7': () => handleNumber('7'),
      '8': () => handleNumber('8'),
      '9': () => handleNumber('9'),
      '.': handleDecimal,
      '+': () => handleOperator('+'),
      '-': () => handleOperator('-'),
      '*': () => handleOperator('*'),
      '/': (e) => { e.preventDefault(); handleOperator('/') },
      'Enter': handleEquals,
      '=': handleEquals,
      'Escape': handleClear,
      'Backspace': () => {
        if (display.length > 1 && !waitingForNext && !justCalculated) {
          setDisplay(display.slice(0, -1) || '0')
        } else {
          setDisplay('0')
        }
      },
      '%': handlePercent,
    }
    const handler = (e) => {
      if (keyMap[e.key]) keyMap[e.key](e)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [handleNumber, handleDecimal, handleOperator, handleEquals, handleClear, handlePercent, display, waitingForNext, justCalculated])

  const displayValue = formatDisplay(display)
  const fontSize = displayValue.length > 10 ? '1.8rem' : displayValue.length > 7 ? '2.4rem' : '3rem'

  return (
    <div className="calc-wrapper">
      <div className="calc-label">CALCULATOR</div>
      <div className="calc-body">
        {/* Display */}
        <div className="display-section">
          <div className="expression">{expression || '\u00A0'}</div>
          <div className="display-value" style={{ fontSize }}>{displayValue}</div>
        </div>

        {/* Divider */}
        <div className="divider" />

        {/* Buttons */}
        <div className="buttons-grid">
          {BUTTONS.map((row, ri) =>
            row.map((btn, bi) => (
              <button
                key={`${ri}-${bi}`}
                className={[
                  'calc-btn',
                  `btn-${btn.type}`,
                  btn.wide ? 'btn-wide' : '',
                  operator === (btn.value || btn.label) && !waitingForNext === false && btn.type === 'operator' ? 'btn-active-op' : '',
                  activeBtn === btn.label ? 'btn-pressed' : '',
                ].filter(Boolean).join(' ')}
                onClick={() => handleClick(btn)}
              >
                <span className="btn-label">{btn.label}</span>
              </button>
            ))
          )}
        </div>
      </div>
      <div className="calc-footer">KEYBOARD SUPPORTED</div>
    </div>
  )
}
